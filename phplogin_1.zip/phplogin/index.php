<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    <link href="sytle.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="register">
    <h1>Register</h1>
    <form action="register.php" method="POST">
        <input type="text" name="name" placeholder="Name"> <br />
        <?php if(isset($error_name)){ ?>
            <p> <?php echo $error_name?> </p>
        <?php }?>
        <input type="email" name="email"  placeholder="Email">
        <input type="password" name="password" placeholder="Password">
        <input type="submit" name="register" value="Register">
    </form>

</div>
</body>

</html>
