<?php


include_once ('config.php');


$name = "";
$email = "";
$password = "";

//if user click register button
if (isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    //validate input
    if (empty($name)){
        $error_name = "Name is required";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $not_email = "Email address is invalid";
    }
    if (empty($email)){
        $error_email = "Email is required";
    }
    if (empty($password)){
        $error_pass = "Password is required";
    }

    $connect_db = mysqli_connect('25.14.30.215', 'test', 'it490123', 'test_database');

    if(!$connect_db){
        exit('Failed to connect to MySQL: ' . mysqli_connect_error());
    }

    $email_sql = "SELECT * FROM users WHERE email='$email'";

    $row = mysqli_fetch_array($email_sql);

    if($row['email'] == $email){
        echo "Email already exist";
        exit();
    }

    $password = password_hash($password, PASSWORD_DEFAULT);

    if(!empty($name) && !empty($email) && !empty($password)){

        $sql = "INSERT INTO users(name, email, password) VALUES ('$name', '$email', '$password')";

        $result = $connect_db->query($sql);

        //header("location:login.php");
    }else{
        header("location:register.php?error=notregister");
    }



}


