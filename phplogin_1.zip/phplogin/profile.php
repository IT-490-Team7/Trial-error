<?php
//This function gets UCID, Password, account, amount instead using multiple $_GET
function get( $fieldname, &$dataOK ){
    global $db, $warning;

    $v = $_GET[$fieldname];
    $v = trim( $v );

    //mysqli_real_escape_string to prevent SQL injection
    $v = mysqli_real_escape_string($db, $v);

    //Checks for empty and bad input
    if (  ($fieldname == "ucid") && ($v == "" )){
        $warning .= "<br><h1>Please provide a Ucid</h1>";
        $dataOK = false;
    }

    if ( ($fieldname == "password") && ($v == "" )   ){
        $warning .= "<br><h1>Please provide a Password</h1>";
        $dataOK = false;
    }

    if (($fieldname == "account") && ($v == "" )){
        $warning .= "<br><h1>Please provide an Account number</h1>";
        $dataOK = false;
    }

    if (  ($fieldname == "amount") && ($v != "" ) && ( !is_numeric($v) ) ){
        $warning .= "<br><h1>Amount must be numeric</h1>";
        $dataOK = false;
    }

    return $v;
}
