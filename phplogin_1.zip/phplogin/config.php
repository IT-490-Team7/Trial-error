<?php
$hostname 	= "25.14.30.215";
$username = "test" ;
$password = "it490123";
$database = "test_database";

$con = mysqli_connect($hostname, $username, $password, $database);
if ( mysqli_connect_errno() ) {
    // If there is an error with the connection, stop the script and display the error.
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}
