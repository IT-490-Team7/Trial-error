
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="login">
    <h1>Login</h1>
    <form action="process.php" method="post">
        <input type="text" name="email" placeholder="Email" id="email">
        <input type="password" name="password" placeholder="Password" >
        <input type="submit" name="login" value="login">
    </form>
</div>
</body>


</html>


